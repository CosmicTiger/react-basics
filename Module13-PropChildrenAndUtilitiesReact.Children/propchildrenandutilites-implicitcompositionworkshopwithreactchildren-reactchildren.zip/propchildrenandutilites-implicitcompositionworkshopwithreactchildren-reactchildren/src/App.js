import React from 'react';
import {Counter, Title, Button, Header} from './components/Counter'

const App = () => (
  <div>
    <Header />
    <Counter>
      <Title />
      <Title>
        {(click) => (
          <div>
            <h1>{click}</h1>
          </div>
        )}
      </Title>
      <Button type='increment' />
      <Button type='decrement' />
    </Counter>
  </div>
)

export default App;
